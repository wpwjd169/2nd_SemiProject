alter table RECORD_WORK_DATA add primary key(member_code);
/
alter table save_rec_email add primary key(member_code);
/
alter table datememo add constraints pk_double_datememo primary key(member_code, datelist_num);