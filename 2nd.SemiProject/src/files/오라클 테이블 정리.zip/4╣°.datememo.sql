create table datememo(
member_code     number(10) not null,
DATELIST_NUM    number(10) not null,
YEAR            varchar2(4) not null,
MONTH           varchar2(2) not null,
DAY             varchar2(2) not null,
MESSAGE         varchar2(4000) not null )