create table account_info(
member_code number(10) constraints member_code_pk primary key,
ID          varchar2(30) not null,
PW          varchar2(50) not null,
NAME        varchar2(50) not null,
DEPARTMENT  varchar2(50) not null,
GENDER      varchar2(10) not null,
EMAIL       varchar2(100) not null )