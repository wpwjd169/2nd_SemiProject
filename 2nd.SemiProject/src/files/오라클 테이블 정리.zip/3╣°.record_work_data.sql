create table RECORD_WORK_DATA(
member_code number(10) not null,
GT_WORK     varchar2(50) not null,
LEV_WORK    varchar2(50) not null )