create table SAVE_REC_EMAIL(
member_code number(10) not null,
SEND_TIME   varchar2(50) not null,
RECEIVER    varchar2(50) not null )
